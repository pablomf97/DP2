The document in this folder is an actual requirement
elicitation document regarding a project in which 
some of the lecturers of Design & Testing are currently
involved with some students from previous classes.

Its only purpose is to provide our current students with 
a real-world requirement elicitation document.  It's very 
likely that your first real-world project will have similar
requirements regading new functionalities, integration with
existing systems, and the like.